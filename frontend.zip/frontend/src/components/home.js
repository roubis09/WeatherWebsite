import React, {useEffect, useState} from 'react'
import {Link} from "react-router-dom";
import Common from './Common.json'
import Searchbar from "./searchbar";
import Button from "./button";
import './css/style.css';
import './css/result.css';

const Home = () => {
    var location = localStorage.getItem('location')
    // const [forecast, setForecast] = useState({
    //     data: []
    // })
    // useEffect(() => {
    //     fetch(`${Common.Forecastapi}${location}/`).then(res => res.json()).then(res => {
    //         setForecast({
    //             data: res.data
    //         })
    //     })
    // }, [])

    const [state, setState] = useState({
        status: true,
        page:'user',
        location: [],
        weather: [],
        sun_time: [],
        forecast: [],
        Error: '',
    })

    const onsubmitform = (event) => {
        event.preventDefault()
        // console.log('aaaa')
        var homeapi = Common.HomePageapi;
        var location = document.getElementById("search").value;
        var formData = new FormData();
        // console.log(location)
        formData.append('location', location.value)
        fetch(`${Common.HomePageapi}${location}/`, {
            method: 'POST',
            body: formData
        }).then((res) => res.json()).then((res) => {
            if (res.Loc){
                // console.log(res.Loc);
                // console.log(res.location);
                // console.log(res.weather);
                localStorage.setItem("location", res.Loc)
                setState({
                    status: false,
                    page: 'user',
                    location: res.location,
                    weather: res.weather,
                    sun_time: res.sun,
                    forecast: res.forecast,
                    Error: '',
                })
            }
            else if (res.Error) {
                    // window.location.href = Common.LoginPageURL
                setState((prevState) => ({...prevState, Error: res.Error, status: false}))
            }
        })
    }
    return(
        <center id="home">
            <Searchbar onsubmitform={onsubmitform}/>
            {/*<form onSubmit={onsubmitform}>*/}
            {/*    <div className="form-group">*/}
            {/*        <input id = "search" type="text" required placeholder="Search places" className="form-control"/>*/}
            {/*    </div>*/}
            {/*    <div className="form-group">*/}
            {/*        <input className="submitButton" type="button" value="Search" onClick={onsubmitform} />*/}
            {/*    </div>*/}
            {/*</form>*/}
            <div>
                {
                    state.status?<div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/></div>
                        :(state.Error)?<h1><br/><br/> {state.Error} <br/><br/><br/><br/><br/></h1>:
                        <section>
                            <h1>CURRENT WEATHER FORECAST</h1>
                            <div className="cards-list">
                                <div id="place">
                                    <div className="cards">
                                        <div className="card 1">
                                            {/*<div className="card_image"><img src="https://i.redd.it/b3esnz5ra34y.jpg"/>*/}
                                            {/*</div>*/}
                                            <div className="card_title">
                                                <img style={{height: 45, marginTop: 10}} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR24ETuX5H84GTzv1iqonAdKSrO3S1lPxbTgQ&usqp=CAU"/>
                                                <p><strong>Place: </strong>{state.location['location_name']}</p>
                                                <p><strong>State: </strong>{state.location['state']}</p>
                                                <p><strong>Country: </strong>{state.location['Country']}</p>
                                                <p><strong>Latitude: </strong>{state.location['latitude']}</p>
                                                <p><strong>Longitude: </strong>{state.location['longitude']}</p>
                                                <p><strong>Date: </strong>{state.location['date']}</p>
                                                <p><strong>Time: </strong>{state.location['time']}</p>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                <div id="temperature">
                                     <div className="cards">
                                        <div className="card 1">
                                            {/*<div className="card_image"><img src="https://i.redd.it/b3esnz5ra34y.jpg"/>*/}
                                            {/*</div>*/}
                                            <div className="card_title">
                                            {/*<h2>Temperature</h2>*/}
                                            <img style={{height: 45, marginTop: 10}} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQY5ZFtKUGcMNKb73YEHI3Cxyg_AH4Y8oqK8g&usqp=CAU"/>
                                            <p><strong>Actual Temperature: </strong>{state.weather['real_temp']}</p>
                                            <p><strong>Feels Like: </strong>{state.weather['temp']}</p>
                                                <p><strong>Pressure: </strong>{state.weather['Pressure']}</p>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                <div id="condition">
                                     <div className="cards">
                                        <div className="card 1">
                                            {/*<div className="card_image"><img src="https://i.redd.it/b3esnz5ra34y.jpg"/>*/}
                                            {/*</div>*/}
                                            <div className="card_title">
                                                <img style={{height: 45, marginTop: 10}} src={state.weather['WeatherIcon']}/>
                                                <p><strong>Condition: </strong>{state.weather['condition']}</p>
                                                <p><strong>Cloud Cover: </strong>{state.weather['CloudCover']}</p>
                                                <p><strong>Humidity: </strong>{state.weather['RelativeHumidity']}</p>
                                                <p><strong>Wind Kph: </strong>{state.weather['Wind']}</p>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                <div id="sun">
                                    <div className="cards">
                                        <div className="card 1">
                                            {/*<div className="card_image"><img src="https://i.redd.it/b3esnz5ra34y.jpg"/>*/}
                                            {/*</div>*/}
                                            <div className="card_title">
                                                <img style={{height: 45, marginTop: 10}} src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSExMWFRUVFhUVGBgVFRUVGBUVFhUWFhUXFxUYHiggGBolHhUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0mICYtLS0tLS0tLS0tLS8tLS0tLSstLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOYA2wMBEQACEQEDEQH/xAAbAAEAAwEBAQEAAAAAAAAAAAAAAgMEAQUGB//EAEIQAAIBAgEIBgcGBAYDAQAAAAABAgMRBAUSITFBUWFxBjKBkaHBExQiQlKx0RVicpKi8DPC4fEjQ1NzgrLS0/IW/8QAGwEBAAMBAQEBAAAAAAAAAAAAAAIDBAEFBgf/xAA+EQACAQICBQkHAwIFBQAAAAAAAQIDEQQxBRIhQVETMmFxgZGhsdEGFCJCweHwFTNScvE0YoKSoiNDssLi/9oADAMBAAIRAxEAPwD9xAAAAOKVwDoAAAAAAAAAAAAAAAAAAAAABxy02AOgAAAAAAAAAAAAAAhKQB2ABIAAAAAAA42ARXMA6mASAAAAAAAABGUrAHI6wCYAAAAAABxsAiwDtnvAJAEJS3ACMQCYAAAAAAAAIvWAGwAkASAAAAAAAIyl3gEEgCxIA6AAAAAAARmAGwB2gHZIAjGIBMAAAAAAAAAA40AcSAJAAAAAAAAArzWAWIAAAAAAAAAAAEc0AkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAV1qubZ72lyu7Lxt3kJz1LN8Uu/7kox1iwmRABnxlTNS4zgu+aTKK89WKfTFd7SLKcbt9T8jQXlYAK69XNSe9xXe0v69hCpPUV+lLvdiUY6xYTIgAAAAAAAAAAAAAAAAAAAAAAAAAhWqKKcnqWvgtr5IjOahHWeR2MXJ2RNEjgAM+UIOVOaWuza5rSvFIz4uLlRko522da2rxLKMkqibLMPVzoxlvSfeidGqqtONRZNJ95GcdWTjwLC0iYsqaof7kPCV/I8/SMtWEP64f+SL6Gb6n5G09AoABjxDzqtOPw5033Zsf+z7jFVnrYmnTW5OT8l5+BdBWpylxsvr9DYbSkAEJ1Emltk7Luu+whKai0uJ1RbTZMmcAAAAAAAAAAAAAAAAAAAAAONXDVwY8BPNcqT1w6vGm+r3auwxYWpqzlh5Zx2rpi8u7J9XSX1VdKot+fX98zabSgMAw5JlaMofBJrsvdeZ5Gh52pzoP5JNdl7o0YlfEpcVc3HrmcwZYlaMP9yPmeLpuerTp/wBcfqzThleT6mbz2jMADBg5Z1WpLdaC7NfieRgZ8ti69XcrQXZn4miqtWnGPabz1zOcbAMeCefKVV6urD8Kel9rXgjDhJ8vJ192Uere/wDU/BIvq/AlT7X1/b1NpuKAAAAAAAAAAAAAAAAAACn09p5j0X6r2S3rmt27ttVytp6ktl8un7rhw2rfaep8Osu3oLi0gADDlKDVqsdcNfGL1o8rSkZ04xxNPnQz6YvNfU0UGneDyfma6NRSipLU1c9CjVjWpqpDJlEouLsyZacPKpTzMVKOycU+1f2Z4FJ8hpScXlNLvS+0jXJa+HT4M9U98yHldIH7MPxp9yZ877RT1aMP6r9yZswS+J9R6p9EYyrE1c2Mpbk2UYqtyNGVTgmyUI60lEy5Ehakm9cm5Pvt5HnaDp6uEUnnJt/T6F+Ld6llu2G89gzGDKNRtqlHXPXwjtPH0nWlOUcHT508+iO/vNFCNr1HkvM204JJJakrI9aEIwioxWxbEUNtu7JEjhGpUUU5N2S0tvYRnNQTlJ7EdSbdkRoVHJXatfUnrtsutj4HKcnKN2rHZKztcsJkQAAAAAAAcbAIq+8AkmAdAKsTQU45r5prQ01qaexoqrUo1Y6svuuldKJwm4O6M+FxDT9HU6y1PUprfwfAx4bFSjU93r8/c90lxXTxXdsLKlNNa8MvI2nolBxq5ySTVmDysn1HSqSoy1PTDt2fvcfPaPqPB4mWDnk3eP50+afE21o8pTVVZ7z1JSPojEePlb2ZwqLWvGzvbxZ8zp1ujWpYhbvo727Vc24X4oygz2YyurrafSxkpJNGJq2w8rL+qC/E+631PmfaaX/Tprpfl9zbgs2+o9Sm7pPgj6WDvFPoMbVmedl2raCj8T8F/Wx4PtFiNTDqmvmfgtvnY1YON563A3YSnmwityXyPYwlLkqEKfBJeBnqS1pN9J2vVUIuT1InXrRo03UlkjkYuTsjz8lQcnKtLXJ2XCK3fvYeRomm6sp4uecti6ujo3dhoxLUbU1kj0kz3DKKk1FNt2SIVKkacXObskdSbdkYqUXWanJWgneEfieyUvJHn4dyxbVaStD5Vx/zP/1XbwL5NUlqrPe/ovqbz0zOAAAADjdgCDk94BYAR3gBsAROXBI6AAZ8ZhlUjbU1pT2pmPHYOOKp6r2NbU96fEspVHB3M+BxrzvRVNE1+pb0YsBpCbn7tidlRf8AL7+e7gratFW5SHN8j0D2TMeZlqhdKa1xezd/c8LTmEc4KvDOPDO32f1NWFqWbi8mX4Gv6SKe3bzPQwGKWJoqe/f1lNWnqSsV5ah/hp7pLx0eaMHtBS18Jrfxaf0+pbhHadugnkirnU0tsXm+a8Gi/QtflcHHjH4e7LwsRxMdWp17TJlx+1BcJfOP0PI9p3+2v6voaMGtjfUelg3/AIcH92PyR9Nh3elF9C8jHU5762eRj5Z9bN2Jxh4rOfj4Hyukpe86ShRWSaX1fh5G6itSlfrZ7p9geceNlKq6k1TjqvZ89vYj5fSlaWMrrCUnsTV+vf8A7V4m6hHk48pL8/uerCCjFRS1Ky7D6WlTjTgoRySsjFJtu7FSaSvJpJbTlWrClBzm7JCMXJ2R51G+IlnNWpRehfG974Hg0lPSlXXmrUYvYv5Pp/Ojia5WoKy5z8D1Uj6IxgAAHEzlwdZ0FTdwCSggCYBxoA4kAU18Nd50W4S3rbwktUl+1YoqUdZ60XaXH1W/z4NFkaltjV1+ZcCqGMcXm1VmvZJaYS7fd5Mze+8jJQxK1eEvlfbu6n3sm6Skr03fo3/c2Jm9O6uig6dBiylgVUV1onHU/I8rSejlioa0dk1k/p6Pc+0voVuTdnk8ynJ2Pb9ieiS0Xe17nxMui9Kuo+QxGya2bd/Q+nzLK9C3xwyNvo76HyfHee7KKknF5Myp22o8WjUdGo09SdpcY61Lnpv3nxeHqy0ZjpU5v4XsfVufZv7T0ZxVamms93oexjqefTklpbWji1pXjY+sxlLlsPOC3p269xhpS1ZpszZKws4OTlZJ20Xu7q+vZt8DztDYCvhIyVRqzs7Lcy3EVYTtq7i3GYBVGm5NWVtFvM04/RdPGOLm2rXytv60yNKu6aaSNFCnmxjHXmpLTwVjdSpqnTjBbkl3FU5a0m+J59DJko1FNyUkm5amnd357WeNQ0PKljPeZTvtbyttfazTPEqVPVSsaMp4r0cNHWloXB7zbpPGe64dzWeS6/sVUKevLbkjJkXD3vN/hX8z8uxnkez2EdpYmeb2L6vtfkX4ueUF1+h6VWooq8nZI+irVoUYOc3ZIyRi5OyPJ9rETtqpx2fvb8j5dSq6Xr22qlH8734Lx2/Dh43zkz2YQSSSVktB9VCEYRUYqyRhbbd2SJnCrEYiMFeTt83yRnxGKpUI3qO3m+pZsnCnKbtFGdekqa704bvflzfuLlp4opg62I2takeHzPr/AI+fSiz4KeW1+H38jVSpqKslZGyMFFWiilybd2cmtPyJHCcUAdAAAAAAAIzgmrNXT2MhOEZxcZK6e46m07o8+phqlLTSd47YP+VniVMHicH8WEd4/wAHt7vy/XkaVUhU2VNj4+pbg8pQnofsy+GWjTwNWD0tRxD1H8MuD49D+mx9BGrh5w25rijaeoZzzcq4LO9uK0rWt6+qPA0xovl1y1Lnrx+63d3A1Yetq/DLIhk3KN7Qm9fVlv3J8eO3nrr0RpjlbUa7+Lc+PX0+ZKvh7fFHtRqxWAjUkpO+hWaWjOWy779W89PF6NoYqpGpUWXj19RTTryhFpF0pQpx0tRilbToSWw2SlTowu2kl2IrSlOWzazF9q538KnKpxtmx/Mzz3pLX/Ypyn05LvZo921f3JJeL7jvpMS/dpx5tt+BF1dIy5sILrbfkNXDre2dz8SvdpvlfzZDlNKR2uEH1NrzFsPxZz7RlH+JTceK0oj+rzpf4mjKPSviXejnu8ZcySZqpVoVFoaktq+qZ6dHEUcTC8GpL8zXqUyhOm9uwshBRjaKslqSLYwjTjqxVktyItuTuzwp1J1521bl8C1Ny4/2Pjq8sRpTE8lZxjF5cOl9PD+7PSjGFCF/x9XR/c9vD0FCKitni97PrcPh6eHpqnTWxflzzpzc3dkqlRRV20lxJ1KsKcdabsuk4otuyPOnlCdR5tGPOctSPEnpSripcngo9cnkvzp29BqVCNNa1V9iNOFwKi86Tzp/E/LcbcJo2FGXK1Hr1P5P6cCqpWclqrYuBrPSKQAAAAAAAcbsG7A5ComrpprencjGSkrxdzrTWxkiRwAAAx43J8amnVLf9d55mP0XRxau9kuPrx/LMvpV5U+rgYI4irRebL2lsvt/DLyZ4ixmN0ZJQrrWhufo/o+w0unTrK8dj/Nx6WFxsKmhOz+F6H/XsPocHpChilem9vB5r84rYZKlGUM8iMcnwU8/ttsUtsuZGOjcPHEPEJfE+6/HrZ115uGoRyhj1TtFLOnLVHze5EsXjFRtGKvJ5L6vgjtGg6m17Es2YIYfOefWefLYvdjyj5mCNDXlymIetLwXUjS56q1aasvFm1Vka+WSKNQl6cg8QjmoFXIe8jUJKsd96Oahkr4aLedH2Jb1oPMrYWm5crQepPisu1fnUy6E2laW1F2CxzbzKmiWx7Jf1/fA9DR+k3VlyNdas/CXUV1aFlrwy8jdGCTbsrvW99tVz11FJtpZmdt2sebisrJaIafvPq9m88LHaepUnqUVrS8F69neaqeFb2y2eZVQwU6rzqjdtz0N8l7qMlDRmJxslVxkmluW/u3eZOVaFJatP89T1qVNRVkrI+mpUYUo6kFZGKUnJ3ZMsOAAAEFVjfNur7r6e4jrxvq32ndV2vbYTJHAAAAAZ62Cpyd3Gz+KN4y/NGzKKmGpT2tbeK2PvVmWRqzjsvs6dq8Sp4apHqVG+E0n+paTLPDYmG2jV7Jq/irPzJ8pTlzo93oQljKsOvSbW+Dv4GaWPxdD9+jdcYO/hn3klSpy5su8lRytSl71nukrFlHTWEqbNaz6fXLxOSwtSO7uNkKilqafJ3PSp1YVFeDTXQ7lDi1mcq01JWaTT3nalOFSLhNXT3MRk4u6PN+ybTTTvBO+nrK2pJ7Two6BhTxMakH8K2239/A1+9Xg01tNmUMYqVNzezQlvb1I9fFYmOHpOo/7soo0nVmoo+cw9Z6aknectLfyXBHz1Kq9tSfOZ6s4LmRyROWMJSxJFUTixpnnizvIk44szSxZx0i2OII+9EHTLFXHvRHkzvpySxRzUKq8lJcdj3EKtRVF0rJ8CcE4s9PJOMz45sutHQ+K2M+o0VjniaVp86Ox+vb5mLE0dSV1k/yxbDAQU3O2lu+nUntaW8vho/DwrOuo/E/DqIOtNx1dxqNpUUVcZTjrmu+77kZK2Ow9H9yaXRfb3ZlkaU5ZIzPK0W7QjKb4IwPTdKT1aMJTfQvx+Bd7rJK82kSjKvLZGmuPtP6FkJ6RrfLGmun4n4WRFqjHe34EvUL9ec58L5sfyxt4mmGD31Zyl1uy7o2Xfcjy1uakvF97NNKlGKtGKS3JJGqFOMFaKSXQVyk5O7dyZMiAAAAAAAAAU18JCfWinx295kr4HD1/3IJvjv71tLIVZw5rMFXI+2Erc/qtR4tb2eSeth5uL6fVWfmaY4t5TRnk69PbK3515tLuMsv1bCcZL/d/9Fi5Cpw8vsenk6tKcFKVrtvVo0J28j6LR9epXw8alVWb4GOtCMJuMTwekuIzqsaeyOl83p+Vu88XTFbXrxpbo7X1v7eZ6eAp6tNz3s8+pVMEqhpjAzzqmeVQtURCRRLaGjTCRSytoujIraINFikczIWGcBYi5nU2SsTwGJzKsZbG818no8ND7D09F4h0cTFvJ7H2+jK69PXptdp9Ljc/MlmO0rXVkm9GtJPhc+zxfK8hLkedbZ19p5NLV11rZHlRwFap120vvNv9K0fI+cjozSOJ/wARUsuF7+C2Gx16UOau71NtDJNOOv2nx0LuR6WH0DhaW2Scn05dy+tyieKnLLYbYQSVkklw0HrwpwgtWCSXRsM7bbuyRM4AAAAAAAAAADlzlwc9It67yLqwWbXedsyLrwXvR70VvE0VnNd6OqEnuZB42mvfj+ZFbx+FWdSP+5ElRqP5X3EHlGl8aIPSWEX/AHY96JchU/iaItNXWp6TammropatsPhsoVb1qkvvyXYnZfI+HxVTWxM5dL8Nh9HQhalFdCM0pGZyuXJHDh06mGctcuhMqaK2i6MyDRBosUyNiNjrmLHLEJTOpEkimpImkTSPuMPUzoxe+Kfern6NTlrwUuKR87NasmipZQpf6ke8zfqGFy5SPeifIVP4smsXTfvx/MiaxmHeVSPejjpTXyvuJqtH4l3osVek8pLvRHVlwJKS3k1OLyZGx0kAAAAAACurRjLrK5CdOM+ciUZuORnnk+l8Gnm/qUSwVCWcfMs94qcSEMl0fg8ZfUzT0Ngp5w8X6nViaq3+Qlkei/d/VL6lX6Fgf4eL9SSxdVbzn2PS2JrtIP2fwfB9533yqceSIfFJdsfNEH7O4R5OS7V6D3ufBfnaReR18cv0/Qrfs3h380vD0O++S4LxPRpwzUluSXcj6CMdWKXAyyd22fB46FqtRffn/wBmfC4iD5ea/wAz82fSUpLk4voXkU6P2iq0eJPacaONWOp3Bw6dTOWONFkZkXEg4k1UI6pyw9INUWIyqHVE7Yrcrk4xuSyPusFG0IJ61GK8Eff0I6tOK4JeR81Vd5t9LMqyNH45/p+h4r9ncNKTk5S29K9DR75LgvH1JrJEN8n2r6E17PYP/N3nPe59A+x6W1N9rJLQGCXyvvZz3urxJLJNFe5+qX1J/oWB/h4y9TjxVV7/ACJrJlL4PGX1L6eisJT5sPF+pz3mrxJRwFNe6vE0xwtKOUSLrVHmy5cNSL0rFR273AEgCMpWAIKIBakAADjYvYGWvlGnHbnPdHT46jzMRpfCUdjnd8Ft+3ey6GHnLd3nn1sryeiKUf1Pu/ueNV9oatR6uHp9+19y9TVHCRW2T9D0cnTlKCz73u9as3p0O3Kx7+j6lWph4yrK0t91bwMlaMVP4cjx8pZDnUqylFxSlZu7d9ST1Ler9p52M0VUq1nODSTzv1dRuoY2FOmoyTujr6Opq2elyj/U69C3VnLw+5z9Qs7qPiTp9GobZyfKy8iS0HStZzl4ehF6Rne6SLl0co75v/kvoSWg8Pvcu9ehF6Qq9BL/APPUN0vzMl+i4Xp7zn6hW4ruD6PUN0vzD9Ew3T3j9QrdHcQl0bo75rtX0IPQWHeUpeHoSWkKvBFM+jMdlSS5pP6FT0DD5ZvtS+xNaSlvijNV6MzWqpF8018rlEtA1FzZp9lvUtjpKO+LKqeQqqlFNJxbV2nqV9L3nIaJrxkk0mr7Xc7LHU5Rb37j6XF1fRwlLalt3t2V+Gk97F1+QoyqJXssjy6UNeaiYqGWE+tG3GLzl3a/meNh/aOhPZVi4+K9fA0TwbXNf0PQo4mE+rJP592s9qhiqNdXpyT6vQzShKPORaaCAAABGYA0ABXAOyAK4q4BZoRy9gZZ5Rpp2Tz3ugs75aDBU0nQi7Rbk+EVreWzxLlQnm9nXsKpVq8upBRW+b8kZZYjSFbZSpKC4ye3uWXiTUKMedK/UV/Zk5/xKrfBKy/fYUy0PXr/AOJrN9Cy9P8AiT95hH9uJfTyXSWy/Nv5ajVR0Jg6fy369vhl4FUsTUe81QpxitCSXBJHpwpwpq0UkujYUyk3mzLiMr4eHWqwT3Zyb7lpKp4uhDnTXeVupFZs83EdLMMtTlJ/di/5rGSel8NHJt9S9bFbxEEZKnTOHuUpS5tLyZnlpun8kG/ztIvErcit9LKz6uG73J/yor/V6r5tLxfoR94luiRfSTFvVQgud/8AyRx6TxTypr87TnL1OBz7fxv+lS8f/YP1HG/wj+f6hy1XgvztJLpBjdtGn2f/AGFpHGb4R/O0ctV4L87SS6TYla8Onyk/6k1pPELOn4neXqb4k49LpLrYaS5Sb+cTq0xJP4qT7/sd94e+JbT6XUH1o1I80mvB+RfHTFB85NfnWSWIjvN+G6QYWWqrFfivH/sjRDSOGnlNduzzJqtB7z0qVaM1eMlJb4tNeBrjOMleLuWJp5FdXB05a4K++1n3rSZ62Cw9b9yCfZt78y2NWccmZqmSIPU5R7b/AD0+J5dT2fwzd6bcX0O/nt8S6OLms0mRjQxEOrOM1ule/eIYXSWH5lRTXCX434nXOhPOLXUWxx0l/EpyjxXtLwNEdI1YbMRRlHpXxLw2og6MXzJJ+BooYqE+rJPhfT3azdQxVGv+3JPz7syqdOcOci1o0EDmkA7mgHQDjXYGDNLAQemSc/xtyX5dS7jO8LTlz1rde1d2XgWqtNc3Z1bPHM0QgkrJJLhoL4xUVZKxW23mQxGJhTWdOUYrfJpfMjOpGCvJ2RFtLM8HG9L6MdFNSqP8se96fA8+rpSlHZBN+C/OwqlWSyPDxfSzET6ubTX3Vd98voefU0liJ82y6tvn6FMq03keVXr1an8SpKX4pN+GpGKfKVOfJvrZW7yzZGNOK4kVRijmqi2Mor3V3X+ZNRitx2yLVi2T1mdO+uPed1mLj1x7xrM7c564941mLj1x7xrM5ceuPeNZi531x7xrM7c5LFX16eZxyvmcKZOD91dmj5EHCL3HLIrUUneLcXvT80RVNRd4uxzV4HoYXLuJp6qrkt0/av2vT4mmni8TTylfr2/fxLFOa3nsYPpnsq0u2D/ll9TdS0q8qke70fqWxr8Ue9gMs0K2iFRX+F+zLuevsPSpYulV5r28MmWxnF5HoGgmU1sLCfWhF8WlfsewpqYelU2zin2E41Jx5rFGhm6nK25ycvF3fidp0lDJu3S7+d34iU9bNLy8i4tIAAAAAxZSyrRoK9SaT2RWmT5Lz1FVWtCmviZFySzPk8pdMKkrqkvRre7Sl9F4nm1cdOWyCt5lMqr3Hz1bESm86cnJ75O78Tz5Jyd5O5U9uZG6OagsM8agscdVHdQWK3iBqCxB4o7yZ2xF4o7yYsPTvYn3MkqL4HdUeln8Mu5kuQlwY1R6Sfwy/Kzvu8uD7hqnPSz+GXcznIS4Map31hrWn3M5yL4DVOLFEeTOWJLFcSPJoWJxxA5MWJqsc1DliXpDmoLEs641BYi2OTFj1Mn9Ia9GyU86Pwz9pW4PWjTSxNWnk7rgycZtH1WS+ldGrZT/AMKX3n7L5S+tj06ONhPZLY/zeXRqJnvpmwsAAAK8RXjTi5TkoxWtt2OOSSuw3Y+Wynl3E1fYwtGoo/6jg03+G6tHm9PIxVK1SWymn12KnJvJHiw6MYyo7yik3pbnNNvnZtmX3SrLa/FkOTkzbR6E1n1qsI8lKXzsWLAS3tHeSZtpdB4+9Wk/wxUfm2WLAR3slyS4mul0Nwy1upLnJeSRYsDTXE7yUTRDothF/lX5zm/MmsJRW7zO8nEn9g4daqEO2KfzLFh6S+VHdSPAfZlJaqVNcoRXkWKnBZJdx2yOPCpaopckkTSSO2K5UWTBVKiztwUyw8jtwQ9WlvY1jpOOHkLnCyNGRy4LY0WcBNYRPXFPmkyLSBL7MpPXSpvnCL8it0oPOK7jlkc+wMO9dCHZG3yIPD0v4o5qR4EZdFcI/wDLtynNeFyp4Si93mc5OJRU6GYd6nUjykn80yt4Gm8rnOSRlq9CI+7WkvxQUvk0QeAjuZHkukw1uhNZdWpTlzzo+TK3gJbmjnJMw1+i2Lj/AJal+Gcfk2mVvB1FuIunIsyfjcbhHb0dRw2xlCTj/wAZLq9mjgSpyrUdztwOpyifYZFy9RxKtF2mtcJdZb7b1xXgehSrxqZZ8C6M0z1S4kLAAAAAAAAAAAA5YA46aFwRdFHbgi8OhcHPVkLgeqoXA9WQuDvq6FwdVBC4JKmhcElFHAdAAAAAAAAAAKqmHhJpyjFtaU2k2nvT2HHFPM5YtOnQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcbAOZ3AAkAAAAAAAAAAcbAIw13AJgAAAAAAAAjncADqYB0AAAAAAAAHGwCty5gFoBAA7cARAJAAAAAAAHGwCvWAWRjYA6AAAAAAARkAcAO7QCQAAAAAAByTAK3pAJqABIAi1tACAJAAAAAAAAAqvcAsjGwB0AAAAAAAAHJIAjcAmkAAAAAAAACp6+IBYkAdAAAAAAAAAAAAAABxIA6AAAAAAAAAAAAAAAAAAAAAAAAAAD/9k="/>
                                                <p><strong>Sunrise: </strong>{state.sun_time['sunrise']}</p>
                                                <p><strong>Sunset: </strong>{state.sun_time['sunset']}</p>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                                {/*<div id="sun">*/}
                                {/*    <p><strong>Sunrise: </strong>{state.weather['RelativeHumidity']}</p>*/}
                                {/*</div>*/}
                            </div>
                            <Link style={{textDecoration: 'none'}}
                              to={{
                                pathname: "/forecast",
                                state: {
                                    forecast: state.forecast
                                }
                              }}
                            ><Button/></Link>
                            {/*<p>{state.forecast[0]['date']}</p>*/}

                        </section>
                }
            </div>
            <footer>
		        <p>Made by Rounik Biswas</p>
	        </footer>
        </center>
    )
}

export default Home;
