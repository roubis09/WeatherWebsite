import React from 'react'
import './css/button.css'

const Button = () => {
    return (
        <div>
            <button className="forecast_btn fifth"> 3 Day Forecast </button>
        </div>
    )
}
export default Button;