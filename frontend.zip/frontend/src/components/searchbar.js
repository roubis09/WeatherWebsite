import React from 'react'
import Common from './Common.json'
import './css/searchbar.css'
import ScriptTag from 'react-script-tag';
import Home from "./home";


const Searchbar = ({onsubmitform}) => {
    return(
        <div>
            <ScriptTag src="https://kit.fontawesome.com/b99e675b6e.js"/>
            <h1>CHECK WEATHER FORECAST</h1>
            <form onSubmit={onsubmitform}>
                <div className="search_wrap search_wrap_3">
                    <div className="search_box">
                        <input type="text" className="input" id="search" placeholder="search place"/>
                            <div className="btn btn_common" type="button" onClick={onsubmitform}>
                                <i className="fas fa-search"></i>
                            </div>
                        </div>
                    </div>
            </form>
        </div>
    )
}

export default Searchbar;