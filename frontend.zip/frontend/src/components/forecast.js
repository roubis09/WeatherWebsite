import React, {useEffect, useState} from 'react'
import {Link} from "react-router-dom";
import './css/forecast.css'
import { Line, Bar } from 'react-chartjs-2'
import Common from "./Common.json";

const Forecast = (props) => {
    var data= props.location.state;
    var forecast= data['forecast'];

    const graph = {
        labels: [
            forecast[0]['date'],
            '',
            forecast[1]['date'],
            '',
            forecast[2]['date']
        ],
        datasets:[
            {
                label: "Temperature",
                data: [
                    forecast[0]['avg_temp'],
                    '',
                    forecast[1]['avg_temp'],
                    '',
                    forecast[2]['avg_temp']
                ],
                borderColor: [
                    'rgba(215, 124, 21, 0.6)',
                    'rgba(215, 124, 21, 0.6)',
                    'rgba(215, 124, 21, 0.6)',
                    'rgba(215, 124, 21, 0.6)',
                    'rgba(215, 124, 21, 0.6)',
                ],
                backgroundColor: [
                    'rgba(215, 124, 21, 0.6)',
                    'rgba(215, 124, 21, 0.6)',
                    'rgba(215, 124, 21, 0.6)',
                    'rgba(215, 124, 21, 0.6)',
                   'rgba(215, 124, 21, 0.6)'
                ]
            },
            {
                label: "Humidity",
                data: [
                    forecast[0]['humidity'],
                    '',
                    forecast[1]['humidity'],
                    '',
                    forecast[2]['humidity']
                ],
                borderColor: [
                    'rgba(23, 218, 122, 0.6)',
                    'rgba(23, 218, 122, 0.6)',
                    'rgba(23, 218, 122, 0.6)',
                    'rgba(23, 218, 122, 0.6)',
                    'rgba(23, 218, 122, 0.6)',
                ],
                backgroundColor: [
                    'rgba(23, 218, 122, 0.6)',
                    'rgba(23, 218, 122, 0.6)',
                    'rgba(23, 218, 122, 0.6)',
                    'rgba(23, 218, 122, 0.6)',
                    'rgba(23, 218, 122, 0.6)'
                ]
            }
        ]
    }
    return (
        <div className="limiter">
            <div className="container-table100">
                <div id="linegraph">
                    <Bar data={graph} />
                </div>
                <div className="wrap-table100">
                    <div className="table100">
                        <table>
                            <thead>
                            <tr className="table100-head">
                                <th className="column1">Date</th>
                                <th className="column2">Condition</th>
                                <th className="column3">Average Temperature</th>
                                <th className="column4">Humidity</th>
                                <th className="column5">Chance Of Rain</th>
                                <th className="column6">Sunrise</th>
                                <th className="column7">Sunset</th>
                            </tr>
                            </thead>
                            <tbody>
                            {
                                forecast.map((loc, index) => {
                                    return (

                                            <tr>
                                                <td className="column1">{loc.date}</td>
                                                <td className="column2">{loc.condition}</td>
                                                <td className="column3">{loc.avg_temp}</td>
                                                <td className="column4">{loc.humidity}</td>
                                                <td className="column5">{loc.chance_of_rain}</td>
                                                <td className="column6">{loc.sunrise}</td>
                                                <td className="column7">{loc.sunset}</td>
                                            </tr>

                                    )
                                })
                            }
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Forecast;