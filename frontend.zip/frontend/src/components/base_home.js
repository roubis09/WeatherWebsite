import React, {useEffect, useState} from 'react'
import {Link} from "react-router-dom";
import Common from './Common.json'
import Searchbar from "./searchbar";
import Home from "./home";

const Base_html = () => {
    const form1 = (event) => {
        event.preventDefault()
        console.log('dfgfdgk')



    }
    return(
        <div>
            <form onSubmit="https://google.com">
                <div className="search_wrap search_wrap_3">
                    <div className="search_box">
                        <input type="text" className="input" id="search" placeholder="search place"/>
                            <div className="btn btn_common" type="button" onClick={form1}>
                                <i className="fas fa-search"></i>
                            </div>
                        <Link to="https://google.com">abc</Link>
                        </div>
                    </div>
            </form>
        </div>

    )

}

export default Base_html;