import './App.css';
import Home from "./components/home";
import Forecast from "./components/forecast";
import Searchbar from "./components/searchbar";
import {BrowserRouter, Route, Link, Switch} from 'react-router-dom'

function App() {
  return (
        // <Search/>
        <BrowserRouter>
          <Switch>
              <Route exact path = '/' component= {Home}/>
              <Route exact path = '/forecast' component= {Forecast}/>
              <Route exact path = '/base' component= {Searchbar}/>
              {/*<Route exact path = '/result' render={(props)=>*/}
              {/*  <div>*/}
              {/*      <Home/>*/}
              {/*      <Searchbar/>*/}
              {/*  </div>*/}

              {/*}/>*/}
          </Switch>
        </BrowserRouter>
  );
}

export default App;

